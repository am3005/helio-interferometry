#!/usr/bin/env python

from distutils.core import setup

setup(name='dliteTools',
      version='1.0',
      description='Module with functions for reading/analyzing DLITE data.',
      author='Joseph Helmboldt',
      url='https://github.com/USNavalResearchLaboratory/DLITE',
      py_modules=['dliteTools'],
     )
